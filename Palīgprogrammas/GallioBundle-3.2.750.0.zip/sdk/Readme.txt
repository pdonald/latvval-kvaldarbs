Gallio SDK
==========

The Gallio SDK is a collection of resources intended to facilitate the development
of Gallio extensions and of new applications that use Gallio.

For documentation see:

http://www.gallio.org/wiki/devel:gallio_sdk